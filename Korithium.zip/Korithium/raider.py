import requests
import time
import random
import json
import phonenumbers
from phonenumbers import geocoder, carrier, timezone
from os import system
myCoolTitle = "Korithium"
# Change the title of the Command Prompt window
system("title " + myCoolTitle)

def read_calling_codes(file_path):
    try:
        with open(file_path, 'r') as file:
            codes = file.readlines()
            codes = [code.strip() for code in codes]
            return codes
    except FileNotFoundError:
        print("The file doesn't exist. Make sure the file path is correct.")
        return []

def get_phone_details(phone_number):
    print("\nPhone Number Details:")
    print(f"Location: {geocoder.description_for_number(phone_number, 'en')}")
    print(f"Carrier: {carrier.name_for_number(phone_number, 'en')}")
    print(f"TimeZone: {timezone.time_zones_for_number(phone_number)}")
    print(f"Number Type: {phonenumbers.number_type(phone_number)}")
    print(f"Number Validity: {phonenumbers.is_valid_number(phone_number)}")
    print(f"Possible Number: {phonenumbers.is_possible_number(phone_number)}")

def get_additional_details_numverify(phone_number):
    api_key = 'NumVerifyApikey'  # Use your provided API key
    response = requests.get(f"http://apilayer.net/api/validate?access_key={api_key}&number={phone_number}")
    data = response.json()
    
    if data.get("valid"):
        print("\nAdditional Details (NumVerify):")
        print(f"International Format: {data.get('international_format')}")
        print(f"Local Format: {data.get('local_format')}")
        print(f"Country Name: {data.get('country_name')}")
        print(f"City: {data.get('location')}")
        print(f"Carrier: {data.get('carrier')}")
        print(f"Line Type: {data.get('line_type')}")

def get_additional_details_numlookup(phone_number):
    api_key = 'NumLookUpApiKey'  # Use your provided Numlookup API key
    response = requests.get(f"https://api.numlookupapi.com/v1/validate?api_key={api_key}&number={phone_number}")
    data = response.json()
    
    if data.get("valid"):
        print("\nAdditional Details (Numlookup API):")
        print(f"International Format: {data.get('international_format')}")
        print(f"Local Format: {data.get('local_format')}")
        print(f"Country Name: {data.get('country_name')}")
        print(f"City: {data.get('location')}")
        print(f"Carrier: {data.get('carrier')}")
        print(f"Line Type: {data.get('line_type')}")

# Load configuration
with open('config.json', 'r') as f:
    config = json.load(f)
    messages = config['messages']

# Generate random message
def get_random_message():
    return random.choice(messages)

header = {'authorization': "tokenForTheFirstAccount"}
header2 = {'authorization': "TokenForTheSecondAccount"}
header3 = {'authorization': "TokenForTheThirdAccount"}
header4 = {'authorization': "TokenForTheFourthAccount"}

# add more headers to add more token.

# Print banner
print(r"""
             ██ ▄█▀ ▒█████   ██▀███   ██▓▄▄▄█████▓ ██░ ██  ██▓ █    ██  ███▄ ▄███▓
             ██▄█▒ ▒██▒  ██▒▓██ ▒ ██▒▓██▒▓  ██▒ ▓▒▓██░ ██▒▓██▒ ██  ▓██▒▓██▒▀█▀ ██▒
            ▓███▄░ ▒██░  ██▒▓██ ░▄█ ▒▒██▒▒ ▓██░ ▒░▒██▀▀██░▒██▒▓██  ▒██░▓██    ▓██░
            ▓██ █▄ ▒██   ██░▒██▀▀█▄  ░██░░ ▓██▓ ░ ░▓█ ░██ ░██░▓▓█  ░██░▒██    ▒██ 
            ▒██▒ █▄░ ████▓▒░░██▓ ▒██▒░██░  ▒██▒ ░ ░▓█▒░██▓░██░▒▒█████▓ ▒██▒   ░██▒
            ▒ ▒▒ ▓▒░ ▒░▒░▒░ ░ ▒▓ ░▒▓░░▓    ▒ ░░    ▒ ░░▒░▒░▓  ░▒▓▒ ▒ ▒ ░ ▒░   ░  ░
            ░ ░▒ ▒░  ░ ▒ ▒░   ░▒ ░ ▒░ ▒ ░    ░     ▒ ░▒░ ░ ▒ ░░░▒░ ░ ░ ░  ░      ░
            ░ ░░ ░ ░ ░ ░ ▒    ░░   ░  ▒ ░  ░       ░  ░░ ░ ▒ ░ ░░░ ░ ░ ░      ░   
            ░  ░       ░ ░     ░      ░            ░  ░  ░ ░     ░            ░   
                                                                        
""")
# Add a few spaces before asking
print("\n\n\n")

# Choose option
print("Choose a tool:")
print("1 - Raider tool")
print("2 - Phone Number Details")

choice = input("Enter your choice: ")

if choice == '1':
    print("Choose a server:")
    print("1 - Private testing server")
    print("2 - Different Server")
    print("3 - Different Server")
    server_choice = input("Enter your choice: ")
    
    # read "README.txt" for info on how to change servers"

    if server_choice == '1':
        url = 'https://discord.com/api/v9/channels/x/messages'
    elif server_choice == '2':
        url = 'https://discord.com/api/v9/channels/x/messages'
    elif server_choice == '3':
        url = 'https://discord.com/api/v9/channels/x/messages'
    else:
        print("Invalid choice. Exiting.")
        input("Press Enter to exit...")

# if you got more than the four headers please copy the last 4 lines before the "input(\nPressEnterToExit)" clone them and then change the last lines in the "r" to the new headers"

    for i in range(100):
        time.sleep(0.1)
        payload = {'content': get_random_message()}
        payload2 = {'content': get_random_message()}
        r = requests.post(url, data=payload, headers=header)
        r = requests.post(url, data=payload2, headers=header)
        payload3 = {'content': get_random_message()}
        payload4 = {'content': get_random_message()}
        r = requests.post(url, data=payload3, headers=header2)
        r = requests.post(url, data=payload4, headers=header2)
        payload5 = {'content': get_random_message()}
        payload6 = {'content': get_random_message()}
        r = requests.post(url, data=payload5, headers=header3)
        r = requests.post(url, data=payload6, headers=header3)
        payload7 = {'content': get_random_message()}
        payload8 = {'content': get_random_message()}
        r = requests.post(url, data=payload7, headers=header4)
        r = requests.post(url, data=payload8, headers=header4)
    input("\nPress Enter to exit...")

elif choice == '2':
    calling_codes_file = 'country_calling_codes.txt'
    calling_codes = read_calling_codes(calling_codes_file)
    
    number = input("Enter your phone number: ")
    
    found_valid_number = False
    for code in calling_codes:
        try:
            full_number = phonenumbers.parse(code + number)
            print(f"Trying with code {code}: {full_number}")
            if phonenumbers.is_valid_number(full_number):
                get_phone_details(full_number)
                get_additional_details_numverify(code + number)
                get_additional_details_numlookup(code + number)
                found_valid_number = True
                break
        except phonenumbers.phonenumberutil.NumberParseException:
            continue
    
    if not found_valid_number:
        print("No valid number found with the provided number and calling codes.")
    
    input("\nPress Enter to exit...")

else:
    print("Invalid choice. Exiting.")
    input("Press Enter to exit...")