Made by ifknhatesam 



The phone number details function doesnt work!

- make sure you just input the number, make sure you don't input stuff like this: "+X 123456789"
- instead just input "123456789"
- open the raider.py file with any text editor and scroll to the line 32. Open any browser and search up "numverify" and "numlookup" then proceed to sign in and get the api keys.

Replace the numer in the line 32 with the api key of numverify, and replace the numer at line 46 with the api key you got from numlookup


How do i add more server options?

- You need to go into ur discord settings
- Go to "advanced"
- turn on "developer mod"
- go to the desired server you wanna raid (make sure that you input your tokens and that all of the accounts are in the server and have perms to speak)
- right click on the channel where the messages are gonna be sent and then click "Copy Id"
- replace the number from one of the lines at 108 - 112 with the copied id (example: the channel id is "XZX", then you the line should look like this: https://discord.com/api/v9/channels/XZX/messages)  )

My Code Doesnt Work!

- make sure you have the correct tokens input and that you have python installed with these libraries:

requests
time
random
json
phonenumbers
os

(to download a library open your cmd, and then type "pip install X".
example: pip install phonenumbers)


IF YOU ARE HAVING PROBLEMS WITH ANYTHING ELSE OR JUST WANT TO SUGGEST SOMETHING, ADD ME ON DISCORD: ifknhatesam
